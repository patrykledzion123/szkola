﻿using System;
using System.Collections.Generic;
 
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfApp1
{
    public class View
    {
        MainWindow window;
        int currentView; //0-D  1-R
        Canvas[] speedometers; // Zegary
        Canvas topPanel; // Wskaznik biegu + kierunkowskazy
        Canvas tempScreen; // Ekran temperatury (lewo)
        Canvas fuelScreen; // Ekran paliwa (prawo)
        Canvas centerScreen; // Przebieg itd
        Canvas lights; //Kontrolka świateł mijania
        Canvas trafficLights; //Kontrolka świateł drogowych

        //BG
        Canvas bgLeftCircle;
        Canvas bgRightCircle;
        Canvas bgTopRect;
        Canvas bgBottomRect;


        public View(MainWindow window)
        {
            this.window = window;
            currentView = 1;
            speedometers = new Canvas[2];
            speedometers[0] = window.SpeedometerL;
            speedometers[1] = window.SpeedometerR;
            topPanel = window.TopPanel;
            tempScreen = window.TempScreen;
            fuelScreen = window.FuelScreen;
            centerScreen = window.CenterScreen;
            lights = window.Lights;
            trafficLights = window.TrafficLights;

            bgLeftCircle = window.BgLeftCircle;
            bgRightCircle = window.BgRigthCircle;
            bgTopRect = window.BgTopRect;
            bgBottomRect = window.BgBottomRect;

            SwitchView();
        }

        void Test()
        {
            speedometers[0].Visibility = Visibility.Hidden;
            speedometers[1].Visibility = Visibility.Hidden;
            topPanel.Visibility = Visibility.Hidden;
            tempScreen.Visibility = Visibility.Hidden;
            fuelScreen.Visibility = Visibility.Hidden;
            centerScreen.Visibility = Visibility.Hidden;
            lights.Visibility = Visibility.Hidden;
            trafficLights.Visibility = Visibility.Hidden;
        }

        public void SwitchView()
        {
            currentView++;
            if (currentView > 1) currentView = 0;

            switch (currentView)
            {
                case 1:
                    //Lewy zegar
                    _ = MoveElementToPoint(speedometers[0], new Point(25,25));

                    SetElementSize(speedometers[0], new Point(150, 150));
                    SetElementSize(speedometers[0].Children[0] as Grid, new Point(150, 150));
                    //speedometers[0].Width = 150;
                    //speedometers[0].Children[0].SetValue(Grid.WidthProperty, 150.0);
                    //speedometers[0].Height = 150;
                    //speedometers[0].Children[0].SetValue(Grid.HeightProperty, 150.0);



                    window.LeftPointer.Height = 75;

                    //Prawy zegar
                    speedometers[1].SetValue(Canvas.LeftProperty, window.Dashboard.Width - 25 - 150);
                    speedometers[1].SetValue(Canvas.TopProperty, 25.0);
                    speedometers[1].Width = 150;
                    speedometers[1].Children[0].SetValue(Grid.WidthProperty, 150.0);
                    speedometers[1].Height = 150;
                    speedometers[1].Children[0].SetValue(Grid.HeightProperty, 150.0);
                    window.RightPointer.Height = 75;

                    //Center screen
                    centerScreen.SetValue(Canvas.TopProperty, -centerScreen.Height);

                    //Temperatura
                    tempScreen.SetValue(Canvas.LeftProperty, -tempScreen.Width);

                    //Paliwo
                    fuelScreen.SetValue(Canvas.LeftProperty, -fuelScreen.Width);

                    //Top panel
                    topPanel.SetValue(Canvas.TopProperty, 16.0);

                    //Lights
                    lights.SetValue(Canvas.TopProperty, 25.0);
                    lights.SetValue(Canvas.LeftProperty, 200.0);

                    //Traffic lights
                    trafficLights.SetValue(Canvas.TopProperty, 25.0);
                    trafficLights.SetValue(Canvas.LeftProperty, 230.0);

                    //Tło
                    window.DashboardBackground.Visibility = Visibility.Hidden;

                    bgTopRect.SetValue(Canvas.HeightProperty, 10.0);
                    bgTopRect.Children[0].RenderTransform = new TranslateTransform(0, -30);
                    (bgTopRect.Children[0] as Rectangle).Fill = new SolidColorBrush(Color.FromArgb(150, 13, 13, 13));

                    (bgLeftCircle.Children[0] as Ellipse).Fill = new SolidColorBrush(Color.FromArgb(0, 13, 13, 13));
                    (bgRightCircle.Children[0] as Ellipse).Fill = new SolidColorBrush(Color.FromArgb(0, 13, 13, 13));

                    bgBottomRect.SetValue(Canvas.TopProperty, window.Dashboard.Height);
                    bgBottomRect.Children[0].RenderTransform = new TranslateTransform(0, bgBottomRect.Height);


                    break;


            }

        }

        private void SetElementSize(Canvas element, Point size)
        {
            if (element == null) return;
            _ = SetElementHeight(element, size.Y);
            _ = SetElementWidth(element, size.X);
        }
        private async Task SetElementWidth(Canvas element, double width)
        {
            while ((double)element.GetValue(Canvas.WidthProperty) < width)
            {
                element.SetValue(Canvas.WidthProperty, (double)element.GetValue(Canvas.WidthProperty) + 1);
                await Task.Delay(5);
            }
            while ((double)element.GetValue(Canvas.WidthProperty) > width)
            {
                element.SetValue(Canvas.WidthProperty, (double)element.GetValue(Canvas.WidthProperty) - 1);
                await Task.Delay(5);
            }
        }

        private async Task SetElementHeight(Canvas element, double height)
        {
            while ((double)element.GetValue(Canvas.HeightProperty) < height)
            {
                element.SetValue(Canvas.HeightProperty, (double)element.GetValue(Canvas.HeightProperty) + 5);
                await Task.Delay(20);
            }
            while ((double)element.GetValue(Canvas.HeightProperty) > height)
            {
                element.SetValue(Canvas.HeightProperty, (double)element.GetValue(Canvas.HeightProperty) - 5);
                await Task.Delay(20);
            }
        }

        private void SetElementSize(Grid element, Point size)
        {
            if (element == null) return;
            _ = SetElementHeight(element, size.Y);
            _ = SetElementWidth(element, size.X);
        }
        private async Task SetElementWidth(Grid element, double width)
        {
            while (element.Width < width)
            {
                element.Width+=5;
                await Task.Delay(20);
            }
            while (element.Width > width)
            {
                element.Width-=5;
                await Task.Delay(20);
            }
        }

        private async Task SetElementHeight(Grid element, double height)
        {
            while ((double)element.GetValue(Grid.HeightProperty) < height)
            {
                element.SetValue(Grid.HeightProperty, (double)element.GetValue(Grid.HeightProperty) + 5);
                await Task.Delay(20);
            }
            while ((double)element.GetValue(Grid.HeightProperty) > height)
            {
                element.SetValue(Grid.HeightProperty, (double)element.GetValue(Grid.HeightProperty) - 5);
                await Task.Delay(20);
            }
        }

        private async Task MoveElementToPoint(Canvas element, Point point)
        {
            double diffX = (double)element.GetValue(Canvas.LeftProperty) - point.X;
            double diffY = (double)element.GetValue(Canvas.TopProperty) - point.Y;
            int timeX = 20;
            int timeY = 20;
            
            if(diffX > diffY)
            {
                timeY = timeX * (int)(diffX / diffY);
            }
            else
            {
                timeX = timeY *  (int)(diffY / diffX);

            }

            //window.text.Text = ((int)(diffX)).ToString();
            window.text.Text = ((int)(diffX / diffY)).ToString();

            _ = MoveElementToX(element, point.X, timeX);
            _ = MoveElementToY(element, point.Y, timeY);
        }

        private async Task MoveElementToX(Canvas element, double x, int time)
        {
            if (element == null) return;
            while ((double)element.GetValue(Canvas.LeftProperty) < x)
            {
                element.SetValue(Canvas.LeftProperty, (double)element.GetValue(Canvas.LeftProperty) + 5);
                await Task.Delay(time);
            }

            while ((double)element.GetValue(Canvas.LeftProperty) > x)
            {
                element.SetValue(Canvas.LeftProperty, (double)element.GetValue(Canvas.LeftProperty) - 5);
                await Task.Delay(time);
            }
        }

        private async Task MoveElementToY(Canvas element, double y, int time)
        {
            if (element == null) return;
            while ((double)element.GetValue(Canvas.TopProperty) < y)
            {
                element.SetValue(Canvas.TopProperty, (double)element.GetValue(Canvas.TopProperty) + 5);
                await Task.Delay(time);
            }

            while ((double)element.GetValue(Canvas.TopProperty) > y)
            {
                element.SetValue(Canvas.TopProperty, (double)element.GetValue(Canvas.TopProperty) - 5);
                await Task.Delay(time);
            }
        }
    }
}
