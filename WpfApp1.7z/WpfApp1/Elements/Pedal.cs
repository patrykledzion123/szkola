﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using static System.Net.Mime.MediaTypeNames;

namespace WpfApp1
{
    public class Pedal
    {
        public MainWindow window;
        public Canvas Element;
        public float angle;
        private bool returnToStartPos;
        private float startPos;
        public float maxAngle;
        public bool isPressed;
        public float startMousePos;
        public float returnSpeed;

        public Pedal(MainWindow window, Canvas el, bool _return)
        {
            this.window = window;
            this.Element = el;
            this.returnToStartPos = _return;
            startPos = 0;
            angle = startPos;
            maxAngle = -20;
            startMousePos = 0;
            isPressed = false;
            returnSpeed = 1.5f;
        }

        public async Task Test()
        {
            while(true)
            {
                while (angle > startPos)
                {
                    angle--;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(10);
                }

                while (angle <= maxAngle)
                {
                    angle++;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(10);
                }
            }
           
        }

        public void GetTargerAngle()
        {
            RotateTransform _rot = new RotateTransform(angle);
            Element.RenderTransform = _rot;
              
        }

        public async Task GetStartPosSoftly()
        {
           
            
            while (angle < startPos)
            {
                angle += returnSpeed;
                RotateTransform _rot = new RotateTransform(angle);
                Element.RenderTransform = _rot;
                
                await Task.Delay(10);
            }

            if (angle < maxAngle) angle = maxAngle;
            if (angle > startPos) angle = startPos;
        }

        public void OnPress()
        {
            window.text.Text = angle.ToString();
            isPressed = true;
            startMousePos = (float)Mouse.GetPosition(window).X;
            
        }

        public void OnDepress()
        {
            isPressed =false;
            window.text.Text = angle.ToString();
            if (angle < maxAngle) angle = maxAngle;
            if (angle > startPos) angle = startPos;
            if (returnToStartPos)
            {
                _= GetStartPosSoftly();
            }


        }

        public void Move()
        {
            if (!isPressed) return;
            if (angle < maxAngle || angle > startPos) return;

            float mousePos = (float)Mouse.GetPosition(window).X;
            angle+= (startMousePos - mousePos) / 3;
            startMousePos = (float)Mouse.GetPosition(window).X;
            
            GetTargerAngle();
        }
    }
}
