﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Media;
using System.Media;
using System.Collections;
using System.Net;
using System.Security.Policy;
using System.Windows.Shapes;
using System.Reflection.Metadata;
using System.ComponentModel;




namespace WpfApp1
{
    public class Functions
    {
        private MainWindow window;

        public bool positionLightsOn = false;
        public bool lightsOn = false;
        public bool trafficLightsOn = false;
        private const int blinkerDelay = 500;
        public bool blinkersWork = false;
        public bool leftBlinkerActivated = false;
        public bool rightBlinkerActivated = false;
        private bool warningLightsActivated = false;
        private SolidColorBrush colorOfBlinkerLightOn = new SolidColorBrush(Colors.Green);
        private SolidColorBrush colorOfBlinkerLightOff = new SolidColorBrush(Colors.Black);
        string blinkerSoundOn;
        string blinkerSoundOff;
        bool soundisPlaying;
        public Functions(MainWindow window)
        {
            this.window = window;
            blinkerSoundOn = "C:/Users/BuyU/source/repos/WpfApp1/WpfApp1/Elements/on.wav";
            blinkerSoundOff = "C:/Users/BuyU/source/repos/WpfApp1/WpfApp1/Elements/off.wav";
            
             
        }

        public async Task BlinkersTask()
        {
            blinkersWork = true;
            var player1 = new MediaPlayer();
            var player2 = new MediaPlayer();
            player1.Open(new Uri(blinkerSoundOn));
            player2.Open(new Uri(blinkerSoundOff));
            player1.MediaEnded += (sender, eventArgs) => soundisPlaying = false;
            while (true)
            {
                while (window.turnLightsLever == null) await Task.Delay(1);
                 


                if (window.turnLightsLever.angle > 2)
                {
                    rightBlinkerActivated = true;
                    leftBlinkerActivated = false;
                    blinkersWork = true;
                }
                else if (window.turnLightsLever.angle < -2)
                {
                    blinkersWork = true;
                    leftBlinkerActivated = true;
                    rightBlinkerActivated = false;
                }
                else
                {
                    leftBlinkerActivated = false;
                    rightBlinkerActivated = false;
                    blinkersWork = false;

                }


                if (warningLightsActivated)
                {
                    soundisPlaying = true;
                    _ = PlaySound(player1);

                    window.LeftBlinker.Fill = colorOfBlinkerLightOn;
                    window.RightBlinker.Fill = colorOfBlinkerLightOn;
                    window._WarningLights_Light.Fill = new SolidColorBrush(Color.FromArgb(255, 130, 0, 0));
                    
                    

                    await Task.Delay(blinkerDelay);
                    soundisPlaying = true;
                    _=  PlaySound(player1);
                    window.LeftBlinker.Fill = colorOfBlinkerLightOff;
                    window.RightBlinker.Fill = colorOfBlinkerLightOff;
                    window._WarningLights_Light.Fill = new SolidColorBrush(Color.FromArgb(255, 30, 0, 0));
                     

                    await Task.Delay(blinkerDelay);

                }
                else
                {
                    if(leftBlinkerActivated && window.engine.engineOn)
                    {
                        window.LeftBlinker.Fill = colorOfBlinkerLightOn;
                        await Task.Delay(blinkerDelay);
                        window.LeftBlinker.Fill = colorOfBlinkerLightOff;
                        await Task.Delay(blinkerDelay);
                    }
                    else if(rightBlinkerActivated && window.engine.engineOn)
                    {
                        window.RightBlinker.Fill = colorOfBlinkerLightOn;
                        await Task.Delay(blinkerDelay);
                        window.RightBlinker.Fill = colorOfBlinkerLightOff;
                        await Task.Delay(blinkerDelay);
                    }
                }
                await Task.Delay(1);
            }

            
        }
        private int  _count = 0;
        public async Task PlaySound(MediaPlayer sp)
        {
            sp.Play();
            await Task.Delay(10);
            sp.Stop();
            _count++;
            window.text.Text = _count.ToString();
        }

        public void LeftBlinkerSwitch()
        {
            if(rightBlinkerActivated) rightBlinkerActivated = false;
            leftBlinkerActivated = !leftBlinkerActivated;
            
        }

        public void RightBlinkerSwitch()
        {
            if(leftBlinkerActivated) leftBlinkerActivated = false;
            rightBlinkerActivated = !rightBlinkerActivated;
           
        }

        public void WarningLightsSwitch()
        {
            warningLightsActivated = !warningLightsActivated;
            
        }

        public void switchPositionLights()
        {
            if(trafficLightsOn) switchTrafficLights();
            if(lightsOn) switchLights();
            switchPositionLightsColor(!positionLightsOn);
            positionLightsOn = !positionLightsOn;
        }

        public void switchPositionLightsColor(bool work)
        {
            SolidColorBrush color = null;

            if (work) color = new SolidColorBrush(Colors.GreenYellow);
            else color = new SolidColorBrush(Colors.Black);

            window.PLights_1.Fill = color;
            window.PLights_2.Fill = color;
            window.PLights_Line_1.Fill = color;
            window.PLights_Line_2.Fill = color;
            window.PLights_Line_3.Fill = color;
            window.PLights_Line_4.Fill = color;
            window.PLights_Line_5.Fill = color;
            window.PLights_Line_6.Fill = color;
        }

        public void switchLights()
        {
            if(!lightsOn)
            {
                if(!positionLightsOn) switchPositionLights();
            }
            else
            {
                if(trafficLightsOn) switchTrafficLights();
            }

            switchLightsColor(!lightsOn);
            lightsOn = !lightsOn;
        }

        public void switchLightsColor(bool work)
        {
            SolidColorBrush? color = null;

            if (work) color = new SolidColorBrush(Colors.GreenYellow);
            else color = new SolidColorBrush(Colors.Black);

            window.Lights_Beam1.Fill = color;
            window.Lights_Beam2.Fill = color;
            window.Lights_Beam3.Fill = color;
            window.Lights_Beam4.Fill = color;
            window.Lights_Beam5.Fill = color;
            window.Lights_Main.Fill = color;
        }

        public void switchTrafficLights()
        {
            if(!trafficLightsOn)
            {
                if(!positionLightsOn) switchPositionLights();
                if(!lightsOn) switchLights();
            }

            switchTrafficLightsColor(!trafficLightsOn);
            trafficLightsOn = !trafficLightsOn;
            
        }

        public void switchTrafficLightsColor(bool work)
        {
            SolidColorBrush color = null;

            if (work) color = new SolidColorBrush(Colors.Blue);
            else color = new SolidColorBrush(Colors.Black);

            window.TLights_Beam1.Fill = color;
            window.TLights_Beam2.Fill = color;
            window.TLights_Beam3.Fill = color;
            window.TLights_Beam4.Fill = color;
            window.TLights_Beam5.Fill = color;
            window.TLights_Main.Fill = color;
        }

        public void switchHandbrakeIcon(bool work)
        {
            SolidColorBrush color = null;

            if (work && window.engine.engineOn) color = new SolidColorBrush(Colors.Red);
            else color = new SolidColorBrush(Colors.Black);

            window.Hand_Brake_Info_1.Fill = color;
            window.Hand_Brake_Info_2.Fill = color;
            window.Hand_Brake_Info_3.Fill = color;
            window.Hand_Brake_Info_4.Fill = color;
        }

        public async Task switchSeatBeltsIcon()
        {
            SolidColorBrush? color = null;

            while (window.seatBelt == null) await Task.Delay(1);

            if(!window.seatBelt.isFastened && window.engine.engineOn) color = new SolidColorBrush(Colors.Red);
            else color = new SolidColorBrush(Colors.Black);

            window.Belts_1.Fill = color;
            window.Belts_2.Fill = color;
            window.Belts_3.Fill = color;
            window.Belts_4.Fill = color;
        }

        public void ChangeGearLetter(int gear, int number) //P R N D
        {
            if (!window.engine.engineOn) return;
            switch (gear)
            {
                case 0:
                    window.GearLetter.Text = "P";
                    break;
                case 1:
                    window.GearLetter.Text = "R";
                    break;
                case 2:
                    window.GearLetter.Text = "N";
                    break;
                case 3:
                    window.GearLetter.Text = "D" + number.ToString();
                    break;
            }
        }

        public void StartEngine()
        {
            if (!window.engine.engineOn) window.engine.engineOn = true;
            else window.engine.engineOn = false;

            switchHandbrakeIcon(window.handbrake.applied);
            _=switchSeatBeltsIcon();


            if (window.engine.engineOn)
            {
                window.StartEngine_Stop.Fill = new SolidColorBrush(Colors.White);
                window.StartEngine_Start.Fill = new SolidColorBrush(Color.FromArgb(255,99,99,99));
            }
            else
            {
                window.StartEngine_Start.Fill = new SolidColorBrush(Colors.White);
                window.StartEngine_Stop.Fill = new SolidColorBrush(Color.FromArgb(255, 99, 99, 99));
            }
        }
    }
}