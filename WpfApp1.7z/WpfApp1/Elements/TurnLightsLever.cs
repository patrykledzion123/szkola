﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfApp1
{
    public class TurnLightsLever
    {
        MainWindow window;
        Grid Element;

        public float posY = 0;
        float minAngle = -9;
        float maxAngle = 9;
        public float angle = 0;

        public bool isPressed = false;


        public TurnLightsLever(MainWindow window)
        {
            this.window = window;
            Element = window._TurnLightsLever;
            _=getTargetAngle();
            _=window.func.BlinkersTask();
        }

        public async Task Test()
        {
            
            if(angle < 0)
            {
                while (angle < maxAngle)
                {
                    angle += 0.5f;
                    getTargetAngle();
                    await Task.Delay(10);
                }
            }else if (angle >= 0)
            {
                while (angle > minAngle)
                {
                    angle -= 0.5f;
                    getTargetAngle();
                    await Task.Delay(10);
                }
            }


        }

        private async Task getTargetAngle()
        {

            if (angle > maxAngle || angle < minAngle) return;

            if (angle > 0)
            {
                while (angle > 0)
                {
                    angle -= 0.5f;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(10);
                }
            }
            else if (angle <= 0)
            {
                while (angle < 0)
                {
                    angle += 0.5f;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(10);
                }
            }

           
           
        }

        public void getAngleFromMousePos()
        {

            if (!isPressed) return;
            Point mousePos = Mouse.GetPosition(window);
             
            double b = mousePos.Y - posY;
             
            this.angle = (float)-b/4;
            window.text.Text = mousePos.Y.ToString();

            if (angle > maxAngle || angle < minAngle) return;

            RotateTransform _rot = new RotateTransform(angle);
            Element.RenderTransform = _rot;
             


        }

        public void ReleaseMouseButton()
        {
            if(!isPressed) return;
            this.isPressed = false;
            _ =getTargetAngle();

            
        }

        public void PressMouseButton()
        {
            this.isPressed = true;
            this.posY = (float)Mouse.GetPosition(window).Y + angle * 2;
            //this.posY = (float)Mouse.GetPosition(window).Y;
        }
 

    }
}
