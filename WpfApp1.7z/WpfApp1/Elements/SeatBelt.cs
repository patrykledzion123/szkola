﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1
{
    public class SeatBelt
    {
        float minPos;
        float maxPos;
        float pos;
        bool isPressed;
        public bool isFastened;
        float startMousePos;
        float startPos;
        Canvas Element;
        Canvas ReleaseButton;
        MainWindow window;

        public SeatBelt(MainWindow window)
        {
            this.maxPos = 85;
            this.minPos = 0;
            this.window = window;
            Element = window._SeatBelt;
            ReleaseButton = window._ReleaseButton;
        }

        public void OnPress()
        {
            if (isPressed || pos == maxPos) return;
            
            isPressed = true;


            startPos = pos;
            startMousePos = (float)Mouse.GetPosition(window).Y; 
        }

        public void Move()
        {
            isFastened = false;
            if (pos == maxPos) isFastened = true;

            if (!isPressed) return;

            float mousePos = (float)Mouse.GetPosition(window).Y;
            pos = startPos + (mousePos - startMousePos);

            
            

            //if (pos < minPos || pos > maxPos) return;
            if (pos > maxPos) pos = maxPos;
            if (pos < minPos) pos = minPos;
            GetTargetPos();

        }

        private void GetTargetPos()
        {
            Thickness _tempMargin = Element.Margin;
            _tempMargin.Top = pos;
            Element.Margin = _tempMargin;
        }


        public async Task GetTargetPosSmooth()
        {
            if (pos == maxPos) return;
            while(pos > minPos)
            {
                pos-=5;
                GetTargetPos();
                await Task.Delay(1);
            }
        }

        public void OnRelease()
        {
            isPressed = false;
            if (pos > maxPos) pos = maxPos;
            if (pos < minPos) pos = minPos;
            _=GetTargetPosSmooth();
        }

        public void ReleaseButtonClick()
        {
            Thickness _tempMargin = ReleaseButton.Margin;
            _tempMargin.Top = 5;
            ReleaseButton.Margin = _tempMargin;

            pos = maxPos - 1;
            _=GetTargetPosSmooth();
        }

        public async Task ReleaseButtonRelease()
        {
            while(pos > maxPos - 10)await Task.Delay(1);
            Thickness _tempMargin = ReleaseButton.Margin;
            _tempMargin.Top = 0;
            ReleaseButton.Margin = _tempMargin;
        }


    }
}
