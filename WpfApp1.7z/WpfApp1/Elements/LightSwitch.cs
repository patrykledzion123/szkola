﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfApp1
{ 
    public class LightSwitch
    {
        MainWindow window;
        Canvas Element;
        float angle;
        int position;
        int maxPosition;
        float[] destinationAngles = {0, 30, 90, 120};
        bool clickable = true;

        public LightSwitch(MainWindow window)
        {
            this.window = window;
            Element = window._LightSwitch_Rotate;
            angle = 0;
            position = 0;
            maxPosition = destinationAngles.Length - 1;
            _=GetAngle(destinationAngles[0]);
        }

        public async Task GetAngle(float _destAngle)
        {
            clickable = false;
            
            if (angle<_destAngle)
            {
                while (angle < _destAngle)
                {
                    angle += 5;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(40);
                }
            }
            else
            {
                while (angle > _destAngle)
                {
                    angle -= 5;
                    RotateTransform _rot = new RotateTransform(angle);
                    Element.RenderTransform = _rot;
                    await Task.Delay(20);
                }
            }
            clickable = true;
            


        }

        public void Click()
        {
            if (!clickable) return;
            position++;
            if(position>maxPosition)
            {
                position = 0;
            }

            _=GetAngle(destinationAngles[position]);

            window.func.positionLightsOn = false;
            window.func.lightsOn = false;

            switch (destinationAngles[position])
            {
                case 30:
                    window.func.positionLightsOn = true;
                    break;
                case 90:
                    window.func.lightsOn = true;
                    window.func.positionLightsOn = true;
                    break;
                case 120:
                    window.func.lightsOn = true;
                    window.func.positionLightsOn = true;
                    window.func.trafficLightsOn = true;
                    break;
                default:
                    window.func.lightsOn = false;
                    window.func.positionLightsOn = false;
                    window.func.trafficLightsOn = false;
                    break;
            }

            window.func.switchPositionLightsColor(window.func.positionLightsOn);
            window.func.switchLightsColor(window.func.lightsOn);
            window.func.switchTrafficLightsColor(window.func.trafficLightsOn);
        }
    }
}
