﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1
{
    public class Shifter
    {
        MainWindow window;
        Grid Element;

        public float pos;
        public float minYPos;
        public float maxYPos;
        private float shifterLength = 96;
        private float[] positions;

        private float startMousePos;
        private float startPos;

        private bool isPressed;

        public int gearPos;

        public Shifter(MainWindow window)
        {
            this.window = window;
            this.Element = window._ShifterBall;
            this.pos = (float)Element.Margin.Top;
            this.minYPos = pos;
            this.maxYPos = minYPos + shifterLength;
            this.gearPos = 0;


            positions = new float[4];

            positions[0] = minYPos;
            positions[1] = minYPos + shifterLength * (1f/3f);
            positions[2] = minYPos + shifterLength * (2f/3f);
            positions[3] = minYPos + shifterLength * (3f/3f);

            startMousePos = pos;
            startPos = pos;

            isPressed = false;

             
        }

        public async Task Test()
        {
            while(true)
            {
                while (pos < maxYPos)
                {
                    pos += 2;
                    foreach(var position in positions)
                    {
                        if (pos == position) await Task.Delay(500);
                    }
                    GetTargetPos();
                    await Task.Delay(10);
                }

                while (pos > minYPos)
                {
                    pos -= 2;
                    foreach (var position in positions)
                    {
                        if (pos == position) await Task.Delay(500);
                    }
                    GetTargetPos();
                    await Task.Delay(10);
                }
            }
            
        }

        private void GetTargetPos()
        {
            Thickness _tempMargin = Element.Margin;
            _tempMargin.Top = pos;
            Element.Margin = _tempMargin;
        }

        private async Task GetTargetPosSmooth(float targetPos)
        {

            while (pos < targetPos)
            {
                pos += 2;
                GetTargetPos();
                await Task.Delay(10);
            }

            while (pos > targetPos)
            {
                pos -= 2;
                GetTargetPos();
                await Task.Delay(10);
            }

            
        }

        public void Click()
        {
            startMousePos = (float)Mouse.GetPosition(window).Y;
            startPos = pos;
            isPressed = true;
        }

        public void StickToNearestShift()
        {
            int min = 0;

            for(int i=0;i<4;i++)
            {
                if (MathF.Abs(pos - positions[i]) < MathF.Abs(pos-positions[min])) min = i;
            }
            window.text.Text = pos.ToString() + " " + positions[3]+" "+(positions[3]-pos).ToString()+" "+min.ToString();
            _=GetTargetPosSmooth(positions[min]);
            gearPos = min;
            ChangeGear();
        }

        public void ReleaseMouseButton()
        {
            if (!isPressed) return;
            isPressed = false;
            this.pos = (float)Element.Margin.Top;
            StickToNearestShift();
        }

        public void Move()
        {
            if (!isPressed) return;

            float mousePos = (float)Mouse.GetPosition(window).Y;
            pos = startPos + (mousePos - startMousePos);

            if (pos < minYPos || pos > maxYPos) return;

            GetTargetPos();
        }

        public void ChangeGear()
        {
            window.engine.ChangeGear(gearPos);
        }
    }
}
