﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace WpfApp1
{
    public class Handbrake
    {
        MainWindow window;
        Grid Element;

        float angle;
        float minAngle;
        float maxAngle;
        public bool applied;
        bool isPressed;
        public float posY;

        public Handbrake(MainWindow window)
        {
            this.window = window;
            this.Element = window._HandBrake;
            this.minAngle = -15;
            this.maxAngle = 5;
            this.angle = maxAngle;
            this.applied = true;
            this.isPressed = false;

            //_ = Test();
        }

        public async Task Test()
        {
            while(true)
            {
                while (angle > minAngle)
                {
                    angle--;
                    GetTargetPos();
                    await Task.Delay(10);
                }
                while (angle < maxAngle)
                {
                    angle++;
                    GetTargetPos();
                    await Task.Delay(10);
                }
            }
            
        }

        private void GetTargetPos()
        {
            RotateTransform _rot = new RotateTransform(angle);
            Element.RenderTransform = _rot;
        }

        public void getAngleFromMousePos()
        {

            if (!isPressed) return;
            Point mousePos = Mouse.GetPosition(window);

            double b = mousePos.Y - posY;

            this.angle = ((float)-(b - minAngle)) / 5;
            window.text.Text = mousePos.Y.ToString();

            if (angle > maxAngle || angle < minAngle) return;

            RotateTransform _rot = new RotateTransform(angle);
            Element.RenderTransform = _rot;

            if (angle > minAngle + 3) applied = true;
            else applied = false;

            if (applied) window.text.Text = "Zaciągnięty";
            else window.text.Text = "Niezaciągniety";
            window.func.switchHandbrakeIcon(applied);
        }

        public void ReleaseMouseButton()
        {
            if (!isPressed) return;
            this.isPressed = false;
            
        }

        public void PressMouseButton()
        {
            this.isPressed = true;
            this.posY = (float)Mouse.GetPosition(window).Y + angle * 2;
            //this.posY = (float)Mouse.GetPosition(window).Y;
        }


    }
}
