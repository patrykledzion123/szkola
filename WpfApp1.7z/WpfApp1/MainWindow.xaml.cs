﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public View view;
        public Functions func;
        public Engine engine;
        public TurnLightsLever turnLightsLever;
        public LightSwitch lightSwitch;
        public Shifter shifter;
        public Handbrake handbrake;
        public Pedal accelerator;
        public Pedal brake;
        public SeatBelt seatBelt;


        private bool seatBeltsFastened = false;

        public MainWindow()
        {
            InitializeComponent();
            view = new View(this);
            func = new Functions(this);
            engine = new Engine(this);
            _ = engine.EngineWork();
            turnLightsLever = new TurnLightsLever(this);
            lightSwitch= new LightSwitch(this);
            shifter = new Shifter(this);
            handbrake = new Handbrake(this);
            this.LeftBlinker.Fill = new SolidColorBrush(Colors.Black);
            this.RightBlinker.Fill = new SolidColorBrush(Colors.Black);
            func.switchHandbrakeIcon(handbrake.applied);
            _=func.switchSeatBeltsIcon();
            accelerator = new Pedal(this, Accelerator, false);
            brake = new Pedal(this, Brake, true);
            seatBelt = new SeatBelt(this);
        }

        private void LeftBlinkerClick(object sender, RoutedEventArgs e)
        {
            func.LeftBlinkerSwitch();
        }

        private void RightBlinkerClick(object sender, RoutedEventArgs e)
        {
            func.RightBlinkerSwitch();
        }

        private void WarningLightsClick(object sender, RoutedEventArgs e)
        {
            func.WarningLightsSwitch();
        }

        private void LightsClick(object sender, RoutedEventArgs e)
        {
            func.switchLights();
        }

        private void TrafficLightsClick(object sender, RoutedEventArgs e)
        {
            func.switchTrafficLights();
        }


        private void AcceleratorPress(object sender, MouseButtonEventArgs e)
        {
            if (!engine.engineOn) return;
            engine.AcceleratorPress();
        }

        private void AcceleratorUp(object sender, MouseButtonEventArgs e)
        {
            if (!engine.engineOn) return;
            engine.AcceleratorUp();
        }

        private void ChangeGearP(object sender, RoutedEventArgs e)
        {
            //0P 1R 2N 3D
            if (!engine.engineOn) return;
            engine.ChangeGear(0);
        }

        private void ChangeGearR(object sender, RoutedEventArgs e)
        {
            if (!engine.engineOn) return;
            engine.ChangeGear(1);
        }

        private void ChangeGearN(object sender, RoutedEventArgs e)
        {
            if (!engine.engineOn) return;
            engine.ChangeGear(2);
        }

        private void ChangeGearD(object sender, RoutedEventArgs e)
        {
            if (!engine.engineOn) return;
            engine.ChangeGear(3);
        }

        private void StartEngine(object sender, RoutedEventArgs e)
        {
           
        }

        private void TurnLightsLeverClick(object sender, RoutedEventArgs e)
        {
            _=turnLightsLever.Test();
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            turnLightsLever.getAngleFromMousePos();
            shifter.Move();
            handbrake.getAngleFromMousePos();
            accelerator.Move();
            brake.Move();
            seatBelt.Move();
            _ = func.switchSeatBeltsIcon();
        }

        private void _TurnLightsLever_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            turnLightsLever.PressMouseButton();
        }

        private void _TurnLightsLever_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            turnLightsLever.ReleaseMouseButton();
        }

        private void Window_MouseUp(object sender, MouseButtonEventArgs e)
        {
            turnLightsLever.ReleaseMouseButton();
            shifter.ReleaseMouseButton();
            handbrake.ReleaseMouseButton();
            accelerator.OnDepress();
            brake.OnDepress();
            seatBelt.OnRelease();
        }

        private void _LightSwitch_Rotate_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            lightSwitch.Click();
        }

        private void _ShifterBall_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            shifter.Click();
        }

        private void Path_MouseDown(object sender, MouseButtonEventArgs e)
        {
            func.StartEngine();
        }

        private void Path_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            handbrake.PressMouseButton();
        }

        private void PositionLightsClick(object sender, RoutedEventArgs e)
        {
            func.switchPositionLights();
        }

        private void checkHandbrake(object sender, MouseEventArgs e)
        {
            func.switchHandbrakeIcon(handbrake.applied);
        }

        private void seatBeltsClick(object sender, RoutedEventArgs e)
        {
            seatBeltsFastened = !seatBeltsFastened;
            
        }

        private void Accelerator_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            accelerator.OnPress();

        }

        private void Brake_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            brake.OnPress();
        }

        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void _SeatBelt_MouseDown(object sender, MouseButtonEventArgs e)
        {
            seatBelt.OnPress();
        }

        private void _SeatBelt_MouseUp(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ReleaseButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            seatBelt.ReleaseButtonClick();
        }

        private void _ReleaseButton_MouseUp(object sender, MouseButtonEventArgs e)
        {
            _ = seatBelt.ReleaseButtonRelease();
        }

        private void _WarningLights_Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            func.WarningLightsSwitch();
        }
    }
}